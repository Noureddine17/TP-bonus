##Exo 1

def conv_bin(chiffre):
    L=[]
    while chiffre>=1:
        L.append(chiffre%2)
        chiffre=chiffre//2
    return L[::-1],len(L)


print("\n----Exo1----\n")

a=conv_bin(9)
print(a)

##Exo 2

def tri_bulles(T):
    n = len(T)
    for i in range(n-1,0,-1):
        for j in range(i):
            if T[j] > T[j+1]:
                temp = T[j]
                T[j] = T[j+1]
                T[j+1] = temp
    return T

def tri_bulles_2_version(T):
    n = len(T)
    for i in range(n-1):
        for j in range(n-i-1):
            if T[j] > T[j+1]:
                temp = T[j]
                T[j] = T[j+1]
                T[j+1] = temp
    return T


print("\n----Exo2----\n")

x=tri_bulles([2,1,3,9,2,1,38,3])
y=tri_bulles_2_version([2,1,3,9,2,1,38,3])

print(x)
print(y)