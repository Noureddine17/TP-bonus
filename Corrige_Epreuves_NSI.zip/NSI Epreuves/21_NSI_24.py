##Exo 1

def recherche(elt,tab):
    L=[]
    if elt not in tab:
        return -1
    for i in range(len(tab)):
        if tab[i]==elt:
            L.append(i)
    return L[-1]

w=recherche(1,[2,3,4])
x=recherche(1,[10,12,1,56])
y=recherche(1,[1,50,1])
z=recherche(1,[8,1,10,1,7,1,8])

print('\n----Exo1----\n')

print(w)
print(x)
print(y)
print(z)

##Exo 2

class AdresseIP:

    def __init__(self, adresse):
        self.adresse = adresse

    def liste_octet(self):
        return [int(i) for i in self.adresse.split(".")]

    def est_reservee(self):
        dernier_octet=self.adresse.split('.')[-1]
        return dernier_octet=='0' or dernier_octet=='255'

    def adresse_suivante(self):
        dernier_octet=int(self.adresse.split('.')[-1])
        if dernier_octet < 254:
            octet_nouveau = dernier_octet + 1
            return AdresseIP('192.168.0.' + str(octet_nouveau))
        else:
            return False

adresse1=AdresseIP('192.168.0.1')
adresse2=AdresseIP('192.168.0.2')
adresse3=AdresseIP('192.168.0.0')

a=adresse1.est_reservee()
b=adresse3.est_reservee()
c=adresse2.adresse_suivante().adresse

print('\n----Exo2----\n')

print(a)
print(b)
print(c)