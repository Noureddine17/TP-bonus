##Exo 1

def convertir(tab):
    binaire=0
    for i in range(len(tab)):
        k=len(tab)-i-1
        binaire+=(tab[k]*2**i)
    return binaire

print('\n----Exo1----\n')

x=convertir([1, 0, 1, 0, 0, 1, 1])
y=convertir([1, 0, 0, 0, 0, 0, 1, 0])

print(x)
print(y)




##Exo 2

def tri_insertion(tab):
    if not tab:
        return tab
    else:
        for i in range(1,len(tab)):
            n=tab[i]
            j=i-1
            while j>=0 and n<tab[j]:
                tab[j],tab[j+1]=tab[j+1],tab[j]
                j-=1
        return tab

print('\n----Exo2----\n')
a=tri_insertion([2,5,-1,7,0,28])
b=tri_insertion([10,9,8,7,6,5,4,3,2,1,0])
print(a)
print(b)
