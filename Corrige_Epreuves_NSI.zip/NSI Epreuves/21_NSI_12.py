
##Exo 1

def maxi(tab):
    maxm=tab[0]
    for j in range(len(tab)):
        if maxm<tab[j]:
            maxm=tab[j]
    for k in range(len(tab)):
        if tab[k]==maxm:
            return (tab[k],k)

print("\n----Exo1----\n")
a=maxi([1,5,6,9,1,2,3,7,9,8])
print(a)

##Exo 2

def recherche(gene, seq_adn):
    n = len(seq_adn)
    g = len(gene)
    i = 0
    trouve = False
    while i < n and trouve == False :
        j = 0
        while j < g and gene[j] == seq_adn[i+j]:
            j+=1
        if j == g:
            trouve = True
        i+=1
    return trouve


print("\n----Exo2----\n")

x=recherche("AGTC", "GTACAAATCTTGCC")
y=recherche("AATC", "GTACAAATCTTGCC")

print(x)
print(y)
