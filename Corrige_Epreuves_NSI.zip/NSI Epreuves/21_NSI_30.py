##Exo 1

def multiplication(a,b):
    if a<0 and b<0:
        a,b=-a,-b
    maxi=max(a,b)
    Quota=0
    for _ in range(maxi):
        Quota+=min(a,b)
    return Quota


print('\n----Exo1----\n')

a=multiplication(3,5)
b=multiplication(-4,-8)
c=multiplication(-2,6)
d=multiplication(-2,0)

print(a)
print(b)
print(c)
print(d)

##Exo 2

def chercher(T,n,i,j):
    if i < 0 or j>len(T) :
        return 'Erreur'
    if i > j :
        return None
    m = (i+j) // 2
    if T[m] > n :
        return chercher(T, n, i , j-1)
    elif T[m]<n :
        return chercher(T, n, i+1 , j )
    else :
        return m

print('\n----Exo2----\n')

w=chercher([1,5,6,6,9,12],7,0,10)
x=chercher([1,5,6,6,9,12],7,0,5)
y=chercher([1,5,6,6,9,12],9,0,5)
z=chercher([1,5,6,6,9,12],6,0,5)

print(w)
print(x)
print(y)
print(z)