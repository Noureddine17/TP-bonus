


##Exo 1
print('\n----Exo1----\n')

def moyenne(tab):
    return sum(tab)/len(tab)


a=moyenne([1.0])
b=moyenne([1.0, 2.0, 4.0])

print(a)
print(b)


##Exo 2
print('\n----Exo2----\n')

def dec_to_bin(a):
    bin_a = str(a%2)
    a = a//2
    while a>0 :
        bin_a = str(a%2) + bin_a
        a =  a//2
    return bin_a


x=dec_to_bin(83)
y=dec_to_bin(127)

print(x)
print(y)