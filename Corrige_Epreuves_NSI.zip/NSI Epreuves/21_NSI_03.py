##Exo 1

def multiplication(a,b):
    if a<0 and b<0:
        a,b=-a,-b
    maxi=max(a,b)
    Quota=0
    for _ in range(maxi):
        Quota+=min(a,b)
    return Quota


print('\n----Exo1----\n')
a=multiplication(3,5)
b=multiplication(-4,-8)
c=multiplication(-2,6)
d=multiplication(-2,0)
L=[a,b,c,d]
for i in range(len(L)):
    print(L[i])


##Exo 2
def dichotomie(tab, x):
    debut = 0
    fin = len(tab) - 1
    while debut <= fin:
        m = (fin-debut)
        if x == tab[m]:
            return True
        if x > tab[m]:
            debut = m + 1
        else:
             fin = m - 1
    return False

print('\n----Exo2----\n')
x=dichotomie([15, 16, 18, 19, 23, 24, 28, 29, 31, 33],28)
y=dichotomie([15, 16, 18, 19, 23, 24, 28, 29, 31, 33],27)
print(x)
print(y)