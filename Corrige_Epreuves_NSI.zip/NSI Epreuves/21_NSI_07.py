##Exo 1

liste_eleves = ['a','b','c','d','e','f','g','h','i','j']
liste_notes = [1, 40, 80, 60, 58, 80, 75, 80, 60, 24]

def meilleures_notes():
    note_maxi = liste_notes[0]
    nb_eleves_note_maxi = 0
    liste_maxi =  []
    for i in range(len(liste_eleves)):
        if liste_notes[i]>note_maxi:
            note_maxi=liste_notes[i]
    for j in range(len(liste_notes)):
        if liste_notes[j]==note_maxi:
            liste_maxi.append(liste_eleves[j])
            nb_eleves_note_maxi+=1
    return (note_maxi,nb_eleves_note_maxi,liste_maxi)

print('\n----Exo1----\n')

a=meilleures_notes()
print(a)


##Exo 2
def fibonacci(n):
    L=[1,1]
    for i in range(1,n-1):
        L.append(L[i-1]+L[i])
    return L[-1]

print('\n----Exo2----\n')

x=fibonacci(1)
y=fibonacci(2)
z=fibonacci(25)
zeta=fibonacci(45)

print(x)
print(y)
print(z)
print(zeta)