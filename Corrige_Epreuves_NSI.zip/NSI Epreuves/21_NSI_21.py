##Exo 1

def nb_repetitions(elt,tab):
    occurence=0
    for i in range(len(tab)):
        if tab[i]==elt:
            occurence+=1
    return occurence


a=nb_repetitions(5,[2,5,3,5,6,9,5])
b=nb_repetitions('A',[ 'B', 'A', 'B', 'A', 'R'])
c=nb_repetitions(12,[1, '! ',7,21,36,44])

print('\n----Exo1----\n')

print(a)
print(b)
print(c)

##Exo 2

def binaire(a):
    bin_a = str(a%2)
    a = a // 2
    while a>0 :
        bin_a = str(a%2) + bin_a
        a = a//2
    return bin_a


x=binaire(0)
y=binaire(77)

print('\n----Exo2----\n')

print(x)
print(y)