##Exo 1

def mini(t_moy,annees):
    min=0
    for i in range(len(t_moy)):
        if t_moy[i]<t_moy[min]:
            min=i
    return t_moy[min],annees[min]

t_moy = [14.9, 13.3, 13.1, 12.5, 13.0, 13.6, 13.7]
annees = [2013, 2014, 2015, 2016, 2017, 2018, 2019]

a=mini(t_moy,annees)
print('\n----Exo1----\n')
print(a)


##Exo 2

def inverse_chaine(chaine):
    result = ""
    for caractere in str(chaine):
       result = caractere+result
    return result

def est_palindrome(chaine):
    inverse = inverse_chaine(chaine)
    return inverse==chaine

def est_nbre_palindrome(nbre):
    chaine = inverse_chaine(nbre)
    return est_palindrome(chaine)

v=inverse_chaine('bac')
w=est_palindrome('NSI')
x=est_palindrome('ISN-NSI')
y=est_nbre_palindrome(214312)
z=est_nbre_palindrome(213312)

print('\n----Exo2----\n')

print(v)
print(w)
print(x)
print(y)
print(z)
