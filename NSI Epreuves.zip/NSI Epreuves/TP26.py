##Exo 1


def occurence_max(chaine):
    Dico={}
    for i in chaine:
        if i not in Dico.keys():
            Dico[i]=1
        else:
            Dico[i]+=1
    key = [k  for (k,val) in Dico.items() if val == max(Dico.values())][0]
    return key

ch="je suis en terminale et je passe le bac et je souhaite poursuivre des etudes pour devenir expert en informatique"

a= occurence_max(ch)

print('\n----Exo1----\n')
print(a)

##Exo 2

def nbLig(image):
    return len(image)

def nbCol(image):
    return len(image[0])

def negatif(image):
    '''renvoie le négatif de l'image sous la forme
       d'une liste de listes'''
    L = [[0 for k in range(nbCol(image))] for i in range(nbLig(image))] # on créé une image de 0 aux mêmes dimensions que le paramètre image
    for i in range(len(image)):
        for j in range(len(image[i])):
            L[i][j] = 255-image[i][j]
    return L

def binaire(image, seuil):
    L = [[0 for k in range(nbCol(image))] for i in range(nbLig(image))] # on crée une image de 0 aux mêmes dimensions que le paramètre image
    for i in range(len(image)):
        for j in range(len(image[i])):
            if image[i][j] < seuil :
                L[i][j] = 0
            else:
                L[i][j] = 1
    return L

img=[[20, 34, 254, 145, 6], [23, 124, 287, 225, 69], [197, 174, 207, 25, 87], [255, 0, 24, 197, 189]]
w=nbLig(img)
x=nbCol(img)
y=negatif(img)
z=binaire(img,120) #La derniere fonction sur le PDF est eronée.

print('\n----Exo2----\n')

print(w)
print(x)
print(y)
print(z)
