##Exo 1

def moyenne(tab):
    if not tab:
        return 'erreur'
    else:
        return sum(tab)/len(tab)


print('\n----Exo1----\n')
x=moyenne([5,3,8])
y=moyenne([1,2,3,4,5,6,7,8,9,10])
z=moyenne([])
print(x)
print(y)
print(z)

print('\n----Exo2----\n')
##Exo 2

def tri(tab):
    i=0
    j=len(tab)-1
    while i != j :
        if tab[i]== 0:
            i+=1
        else :
            valeur = tab[j]
            tab[j] = tab[i]
            tab[i]=valeur
            j-=1
    return tab

a=tri([0,1,0,1,0,1,0,1,0])
print(a)