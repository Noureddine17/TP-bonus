##Exo 1

def recherche(tab,elt):
    if elt not in tab:
        return -1
    for i in range(len(tab)):
        if tab[i]==elt:
            return i

a=recherche([2, 3, 4, 5, 6], 5)
b=recherche([2, 3, 4, 6, 7], 5)

print('\n----Exo1----\n')

print(a)
print(b)


##Exo 2

ALPHABET='ABCDEFGHIJKLMNOPQRSTUVWXYZ'

def position_alphabet(lettre):
    return ALPHABET.find(lettre)

def cesar(message, decalage):
    resultat = ''
    for lettre in message :
        if lettre in ALPHABET :
            indice = (position_alphabet(lettre)+decalage)%26
            resultat = resultat + ALPHABET[indice]
        else:
            resultat = resultat+lettre
    return resultat


x=cesar('BONJOUR A TOUS. VIVE LA MATIERE NSI !',4)
y=cesar('GTSOTZW F YTZX. ANAJ QF RFYNJWJ SXN !',-5)

print('\n----Exo2----\n')

print(x)
print(y)