##Exo 1

def rechercheMinMax(tab):
    Dico={'min':None,'max':None}
    if not tab:
        return Dico
    mini,maxi=0,0
    for i in range(len(tab)):
        if tab[i]>tab[maxi]:
            maxi=i
        elif tab[i]<tab[mini]:
            mini=i
    Dico['min']=tab[mini]
    Dico['max']=tab[maxi]
    return Dico


print('\n----Exo1----\n')

a=rechercheMinMax([0, 1, 4, 2, -2, 9, 3, 1, 7, 1])
b=rechercheMinMax([])

print(a)
print(b)



##Exo 2

class Carte:
    """Initialise Couleur (entre 1 à 4), et Valeur (entre 1 à 13)"""
    def __init__(self, c, v):
        self.Couleur = c
        self.Valeur = v

    """Renvoie le nom de la Carte As, 2, ... 10,
       Valet, Dame, Roi"""
    def getNom(self):
        if ( self.Valeur > 1 and self.Valeur < 11):
            return str( self.Valeur)
        elif self.Valeur == 11:
            return "Valet"
        elif self.Valeur == 12:
            return "Dame"
        elif self.Valeur == 13:
            return "Roi"
        else:
            return "As"

    """Renvoie la couleur de la Carte (parmi pique, coeur, carreau, trefle"""
    def getCouleur(self):
        return ['pique', 'coeur', 'carreau', 'trefle' ][self.Couleur]

class PaquetDeCarte:
    def __init__(self):
        self.contenu = []
        self.remplir()
    """Remplit le paquet de cartes"""
    def remplir(self):
        for i in range(4):
            for j in range(14):
                self.contenu.append(j)


    """Renvoie la Carte qui se trouve à la position donnée"""
    def getCarteAt(self, pos):
        valeur=self.contenu[pos]
        couleur=0
        i=0
        while self.contenu[i]!=valeur or i!=pos:
            if self.contenu[i]==valeur:
                couleur+=1
            i+=1
        self.Carte=Carte(couleur,valeur)
        return self.Carte

print('\n----Exo2----\n')
print('>>>unPaquet = PaquetDeCarte()\n>>>uneCarte = unPaquet.getCarteAt(20)\n')

unPaquet = PaquetDeCarte()
uneCarte = unPaquet.getCarteAt(20)
print(uneCarte.getNom() + " de " + uneCarte.getCouleur())