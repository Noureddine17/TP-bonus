##Exo 1

def recherche(tab):
    L=[]
    for i in range(len(tab)-1):
        if tab[i]-tab[i+1]==-1:
            L.append([tab[i],tab[i+1]])
    return L

w=recherche([1, 4, 3, 5])
x=recherche([1, 4, 5, 3])
y=recherche([7, 1, 2, 5, 3, 4])
z=recherche([5, 1, 2, 3, 8, -5, -4, 7])

print('\n----Exo1----\n')

print(w)
print(x)
print(y)
print(z)

##Exo 2

def propager(M, i, j, val):
    if M[i][j]== 0:
        return M

    M[i][j]=val

    # l'élément en haut fait partie de la composante
    if ((i-1) >= 0 and M[i-1][j] == 1):
        propager(M, i-1, j, val)

    # l'élément en bas fait partie de la composante
    if ((i+1) < len(M) and M[i+1][j] == 1):
        propager(M, i+1, j, val)

    # l'élément à gauche fait partie de la composante
    if ((i) >= 0 and M[i][j-1] == 1):
        propager(M, i, j-1, val)

    # l'élément à droite fait partie de la composante
    if ((i) < len(M) and M[i][j+1] == 1):
        propager(M, i, j+1, val)


M = [[0,0,1,0],[0,1,0,1],[1,1,1,0],[0,1,1,0]]
a=propager(M,2,1,3)

print('\n----Exo2----\n')

print(M)