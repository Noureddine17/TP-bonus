##Exo 1

def moyenne(tab):
    Coef_total=0
    Note_total=0
    for i in range(len(tab)):
        Note_total+=tab[i][0]*tab[i][1]
        Coef_total+=tab[i][1]
    return Note_total/Coef_total

print("\n----Exo1----\n")

x=moyenne([[15,2],[9,1],[12,3]])
print(x)

##Exo 2

def pascal(n):
    C= [[1]]
    for k in range(1,n):
        Ck = [1]
        for i in range(1,k):
            Ck.append(C[k-1][i-1]+C[k-1][i] )
        Ck.append(1)
        C.append(Ck)
    return C


print("\n----Exo2----\n")

a=pascal(4)
b=pascal(5)

print(a)
print(b)