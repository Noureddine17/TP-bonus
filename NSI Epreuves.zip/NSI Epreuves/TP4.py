##Exo 1

def moyenne(tab):
    if not tab:
        return 'erreur'
    else:
        return sum(tab)/len(tab)


print("\n----Exo1----\n\nAucune erreur avec les asserts, donc c'est bon")

assert moyenne([1]) == 1
assert moyenne([1,2,3,4,5,6,7]) == 4
assert moyenne([1,2]) == 1.5


##Exo 2

def dichotomie(tab, x):
    """
        tab : tableau trié dans l’ordre croissant
        x : nombre entier
        La fonction renvoie True si tab contient x et False sinon
    """
    # cas du tableau vide
    if not tab:
        return False,1

    # cas où x n'est pas compris entre les valeurs extrêmes
    if (x < tab[0]) or x>tab[-1]:
        return False,2

    debut = 0
    fin = len(tab) - 1
    while debut <= fin:
        m = fin-debut
        if x == tab[m]:
            return True
        if x > tab[m]:
            debut = m + 1
        else:
            fin = m-1
    return False,3
print("\n----Exo2----\n")

x=dichotomie([15, 16, 18, 19, 23, 24, 28, 29, 31, 33],28)
y=dichotomie([15, 16, 18, 19, 23, 24, 28, 29, 31, 33],27)
z=dichotomie([15, 16, 18, 19, 23, 24, 28, 29, 31, 33],1)
zeta=dichotomie([],28)

print(x)
print(y)
print(z)
print(zeta)