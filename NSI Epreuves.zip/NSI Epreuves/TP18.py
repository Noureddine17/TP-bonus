##Exo 1


def recherche(elt,tab):
    if elt not in tab:
        return -1
    for i in range(len(tab)):
        if tab[i]==elt:
            return i


w=recherche(1, [2, 3, 4])
x=recherche(1, [10, 12, 1, 56])
y=recherche(50, [1, 50, 1])
z=recherche(15, [8, 9, 10, 15])

print('\n----Exo1----\n')

print(w)
print(x)
print(y)
print(z)


##Exo 2


def insere(a, tab):
    l = list(tab)
    l.append(a)
    i = len(tab)-1
    while a < l[i] and i>=0 :
        l[i+1] = l[i]
        l[i] = a
        i -=1
    return l

a=insere(3,[1,2,4,5])
b=insere(10,[1,2,7,12,14,25])
c=insere(1,[2,3,4])

print('\n----Exo2----\n')

print(a)
print(b)
print(c)